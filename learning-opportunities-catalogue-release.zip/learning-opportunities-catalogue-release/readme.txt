=== Learning Opportunities Catalogue ===
Contributors: atanasangelovdev
Tags:
Requires at least: 4.7.0
Tested up to: WordPress 5.4
Requires PHP: 5.5.9
Stable tag: 1.0
License: GPL-2.0-only
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A modern WordPress starter plugin which uses the [WP Emerge](https://github.com/htmlburger/wpemerge) framework.

== Description ==

This is the long description. No limit, and you can use Markdown (as well as in the following sections).

== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif).
2. This is the second screen shot.

== Changelog ==

= 1.0 =
* Released: January 1, 2019

Initial release

== Resources ==
