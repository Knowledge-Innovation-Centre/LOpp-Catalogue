<?php
/**
 * An example partial view.
 *
 * @package LearningOpportunitiesCatalogue
 */

?>
<div class="learning_opportunities_catalogue__partial">
	<?php echo esc_html( $message ); ?>
</div>
