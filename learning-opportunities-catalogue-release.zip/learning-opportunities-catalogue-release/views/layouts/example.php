<?php
/**
 * An example layout.
 *
 * @link https://docs.wpemerge.com/#/framework/views/layouts
 *
 * @package LearningOpportunitiesCatalogue
 */

?>
<div class="learning_opportunities_catalogue__layout">
	<?php \LearningOpportunitiesCatalogue::layoutContent(); ?>
</div>
