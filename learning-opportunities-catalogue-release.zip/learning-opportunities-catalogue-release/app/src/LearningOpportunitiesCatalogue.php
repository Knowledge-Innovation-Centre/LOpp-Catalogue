<?php

use WPEmerge\Application\ApplicationTrait;

/**
 * @mixin \WPEmergeAppCore\Application\ApplicationMixin
 */
class LearningOpportunitiesCatalogue {
	use ApplicationTrait;
}
